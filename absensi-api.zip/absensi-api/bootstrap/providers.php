<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RateLimiterServiceProvider::class,
];
